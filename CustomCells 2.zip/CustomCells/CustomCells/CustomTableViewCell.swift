//
//  CustomTableViewCell.swift
//  CustomCells
//
//  Created by User on 07.11.2024.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var label : UILabel!
    @IBOutlet weak var label2 : UILabel!

}
